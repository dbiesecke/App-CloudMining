App-CloudMining
===============

perl app to show stats from cloud mining provider like zencloud
